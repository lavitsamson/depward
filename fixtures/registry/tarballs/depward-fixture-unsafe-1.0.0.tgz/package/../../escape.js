// Synthetic, inert fixture: path traversal entry.
